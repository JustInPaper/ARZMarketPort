require("ArizonaAPI") 

function main()
    AFKMessage('Always day by Freym loaded')
end

function onWorldTime(nHour) 
    return false
end

function onSetTimeEx(nHour, nMinute) 
    return false
end

function onWeather(nWeather) 
    return false
end

AFKMessage = function(text) 
	sampAddChatMessage('[Freym-tech] {ffffff}'..tostring(text),0xFF4141) 
end


