-- script author: fokichevskiy

require('lts')
local ffi = require('ffi')
ffi.cdef[[
	typedef void* HANDLE;
	typedef void* LPSECURITY_ATTRIBUTES;
	typedef unsigned long DWORD;
	typedef int BOOL;
	typedef const char *LPCSTR;
	typedef struct _FILETIME { 
        DWORD dwLowDateTime;
        DWORD dwHighDateTime;
	} FILETIME,  *PFILETIME, *LPFILETIME;
	BOOL __stdcall GetFileTime(HANDLE hFile, LPFILETIME lpCreationTime, LPFILETIME lpLastAccessTime, LPFILETIME lpLastWriteTime);
	HANDLE __stdcall CreateFileA(LPCSTR lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode, LPSECURITY_ATTRIBUTES lpSecurityAttributes, DWORD dwCreationDisposition, DWORD dwFlagsAndAttributes, HANDLE hTemplateFile);
    BOOL __stdcall CloseHandle(HANDLE hObject);
]]

local scripts = {}


function onScriptLoad()
    scripts = getAllScripts()
end

function onUpdate()
    if isKeyDown(82) and isKeyPressed(17) then
        addMessage('Reloading all scripts', 1000, 0, 0)
        print('AutoReload: Reloading all scripts')
        scripts = getAllScripts()
        if #scripts ~= 0 then
            for k, v in pairs(scripts) do
                unloadScript(v.dir)
                loadScript(v.dir)
            end
        else
            print('err')
        end
    end
end

newTask(function ()
  while true do
    if #scripts > 0 then
        for k, v in pairs(scripts) do
            local time = get_file_time(getWorkingDirectory() .. '\\' .. v.dir)
            if time ~= v.time and time ~= nil then
                print('AutoReload: Reloading ' .. v.dir)
                unloadScript(v.dir)
                loadScript(v.dir)
                scripts = getAllScripts()
            end
        end
    end
    wait(500)
  end
end)

function getAllScripts()
    local scr = {}
    for dir in io.popen('dir "' .. getWorkingDirectory() .. '"\\ /b'):lines() do
        if dir:find('.lua') then
            if dir ~= 'AutoReload.lua' then
                local time = get_file_time(getWorkingDirectory() .. '\\' .. dir)
                table.insert(scr, {dir = dir, time = time})
            end
        end
    end
    return scr
end

function get_file_time(directory) -- https://stackoverflow.com/questions/30705318/how-to-use-getfiletime-in-c
    local handle = ffi.C.CreateFileA(directory, 0x80000000, 0x00000001, nil, 3, 0x80, nil) -- https://learn.microsoft.com/ru-ru/windows/win32/secauthz/generic-access-rights and https://learn.microsoft.com/ru-ru/windows/win32/api/fileapi/nf-fileapi-createfilea
    local filetime = ffi.new('FILETIME[3]')
    if handle ~= 1 then
        local res = ffi.C.GetFileTime(handle, filetime, filetime + 1, filetime + 2)
        ffi.C.CloseHandle(handle)
        if res == 1 then
            return filetime[2].dwLowDateTime
        end
    end
end

function scan_directory(directory)
    local iopop = io.popen('dir "'..directory..'"')
    local output = iopop:read"*a"
    iopop:close()
    return output:match"(.+)%.lua"
end