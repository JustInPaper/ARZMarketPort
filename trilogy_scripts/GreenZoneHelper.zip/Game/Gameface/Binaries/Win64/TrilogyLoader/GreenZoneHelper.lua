require("ArizonaAPI")
require("lts")
local ffi = require("ffi")
local oldtime = os.clock() - 1
local gz_informer = ''

ffi.cdef"int GetSystemMetrics(int);"

function main()
    AFKMessage('GreenZoneHelper By Freym loaded.')
    local sX, sY = getScreenResolution()
    X = sX/21.524501208
    Y = sY/1.047578378
end

function getScreenResolution()
    return ffi.C.GetSystemMetrics(0), ffi.C.GetSystemMetrics(1)
end


function onUpdate()
    local nId = renderAddText(X , Y, 0xFFFCE5CD, 37, 'GREENZONE: '..gz_informer)
    newTask(function()
        wait(40)
        renderEnd(nId)
    end)
    if (os.clock() - oldtime) > 1.3 and sampIsLocalPlayerConnected() == true then 
        oldtime = os.clock()
        sampSendCommand('/gzinfo')
    end
end

function onClientMessage(message, color)
    return onServerMessage(color, message)
end

function onServerMessage(color, text)
	if text:find('E_CURRENT_AREA_TYPE_INDEX') and color == 4278190335 then
		return false
	end
	if text:find('E_AREA_TYPE_ID') and color == 4278190335 then
		return false
	end
    if text:find('current gz index') and color == 4278190335 then
        if text:find('65535') then
            gz_informer = 'NO'
        else
            gz_informer = 'YES'
        end
        return false
    end
    return true
end

AFKMessage = function(text) 
	sampAddChatMessage('[Freym-tech] {ffffff}'..tostring(text),0xFF4141) 
end
